import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: any, min?: any,max? :any): any {
    return min ? items.filter((range :any) => range.precentage >= min && range.precentage <= max) : items;
}

}
