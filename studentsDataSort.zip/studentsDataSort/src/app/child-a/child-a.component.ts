import { Component, OnInit } from '@angular/core';
import{ CommonService} from '../service/common.service';

@Component({
  selector: 'app-child-a',
  templateUrl: './child-a.component.html',
  styleUrls: ['./child-a.component.css']
})
export class ChildAComponent implements OnInit {
  studentData:any;
  sendfromData:any;
  options: string[] = ["0-10", "11-20", "21-30","31-40","41-50","51-60","61-70","71-80","81-90","91-100"];
  slectedRang = "0-10";
  selectedRange:any ="0-10";
  constructor( private CommonService:CommonService) { }

  ngOnInit(): void {
    this.CommonService.sendStudentsRange(this.slectedRang);
  }

  getStudentData(){
    this.CommonService.getStudents().subscribe(x=>{
        this.studentData=x;
    });
  }

  changeRange(rangeData:any){
    this.selectedRange = rangeData;
    this.CommonService.sendStudentsRange(this.selectedRange);
  }
}
