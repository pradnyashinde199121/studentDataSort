import { Component, Input, OnInit } from '@angular/core';
import {CommonService} from '../service/common.service'
@Component({
  selector: 'app-child-b',
  templateUrl: './child-b.component.html',
  styleUrls: ['./child-b.component.css']
})
export class ChildBComponent implements OnInit {
  currentRange:any;
  min:any;
  max:any;
  @Input() data:any;

  constructor( private CommonService:CommonService) { }

  ngOnInit(): void {
    this.getRange();
  }

  getRange(){
    this.CommonService.getSelectectedRange().subscribe(x=>{
      if(x!= null)
      {
        this.currentRange=x;
        var rangeList= this.currentRange.split("-");
        this.min = rangeList[0];
        this.max = rangeList[1];
      }
    
    });
  }

}
