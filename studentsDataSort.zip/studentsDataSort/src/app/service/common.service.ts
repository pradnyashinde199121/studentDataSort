import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private studentsDetail = new BehaviorSubject(null);  

  constructor(private http:HttpClient) { }

  getStudents(){
    const url="/assets/studentData.json";
    return this.http.get(url);
  }
  sendStudentsRange(data:any){
    this.studentsDetail.next(data);
  }
  getSelectectedRange(){  
    return this.studentsDetail.asObservable();  
}  
}
